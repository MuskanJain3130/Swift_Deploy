import React from 'react'

function Home() {
  return (
    <div>
      Home page
    </div>
  )
}

export default Home
