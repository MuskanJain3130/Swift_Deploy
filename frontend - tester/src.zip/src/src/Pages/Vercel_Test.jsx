function Vercel_Test() {
  return (
    <div>
      <form action="/api/vercel_test" method="POST">
      </form>
    </div>
  )
}

export default Vercel_Test